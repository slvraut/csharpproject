﻿namespace Lift
{
    partial class Elevator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Data = new System.Windows.Forms.ListBox();
            this.moveuptimer = new System.Windows.Forms.Timer(this.components);
            this.movedowntimer = new System.Windows.Forms.Timer(this.components);
            this.upOpenTimer = new System.Windows.Forms.Timer(this.components);
            this.downOpenTimer = new System.Windows.Forms.Timer(this.components);
            this.downclosetimer = new System.Windows.Forms.Timer(this.components);
            this.upclosetimer = new System.Windows.Forms.Timer(this.components);
            this.timeauto = new System.Windows.Forms.Timer(this.components);
            this.timerautoup = new System.Windows.Forms.Timer(this.components);
            this.timerautodown = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnView = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.updisplay = new System.Windows.Forms.PictureBox();
            this.buttonS = new System.Windows.Forms.Button();
            this.buttonF = new System.Windows.Forms.Button();
            this.downdisplay = new System.Windows.Forms.PictureBox();
            this.buttonclose = new System.Windows.Forms.Button();
            this.Sbutton = new System.Windows.Forms.Button();
            this.buttonopen = new System.Windows.Forms.Button();
            this.Fbutton = new System.Windows.Forms.Button();
            this.rightup = new System.Windows.Forms.PictureBox();
            this.Indisplay = new System.Windows.Forms.PictureBox();
            this.leftup = new System.Windows.Forms.PictureBox();
            this.leftdown = new System.Windows.Forms.PictureBox();
            this.rightdown = new System.Windows.Forms.PictureBox();
            this.inside = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updisplay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.downdisplay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Indisplay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftdown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightdown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inside)).BeginInit();
            this.SuspendLayout();
            // 
            // Data
            // 
            this.Data.FormattingEnabled = true;
            this.Data.Items.AddRange(new object[] {
            "Data"});
            this.Data.Location = new System.Drawing.Point(322, 44);
            this.Data.Name = "Data";
            this.Data.Size = new System.Drawing.Size(319, 303);
            this.Data.TabIndex = 19;
            // 
            // moveuptimer
            // 
            this.moveuptimer.Interval = 5;
            this.moveuptimer.Tick += new System.EventHandler(this.moveuptimer_Tick_1);
            // 
            // movedowntimer
            // 
            this.movedowntimer.Interval = 5;
            this.movedowntimer.Tick += new System.EventHandler(this.movedowntimer_Tick_1);
            // 
            // upOpenTimer
            // 
            this.upOpenTimer.Interval = 25;
            this.upOpenTimer.Tick += new System.EventHandler(this.upOpenTimer_Tick_1);
            // 
            // downOpenTimer
            // 
            this.downOpenTimer.Interval = 25;
            this.downOpenTimer.Tick += new System.EventHandler(this.downOpenTimer_Tick_1);
            // 
            // downclosetimer
            // 
            this.downclosetimer.Interval = 25;
            this.downclosetimer.Tick += new System.EventHandler(this.downclosetimer_Tick_1);
            // 
            // upclosetimer
            // 
            this.upclosetimer.Interval = 25;
            this.upclosetimer.Tick += new System.EventHandler(this.upclosetimer_Tick_1);
            // 
            // timeauto
            // 
            this.timeauto.Interval = 5000;
            this.timeauto.Tick += new System.EventHandler(this.timerauto_Tick_1);
            // 
            // timerautoup
            // 
            this.timerautoup.Interval = 25;
            this.timerautoup.Tick += new System.EventHandler(this.timerautoup_Tick);
            // 
            // timerautodown
            // 
            this.timerautodown.Interval = 25;
            this.timerautodown.Tick += new System.EventHandler(this.timerautodown_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnView);
            this.groupBox1.Location = new System.Drawing.Point(321, 2);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(318, 43);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 22);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 24;
            this.label2.Text = "Date and Time";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(214, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 23;
            this.label1.Text = "Activity";
            // 
            // btnView
            // 
            this.btnView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnView.Location = new System.Drawing.Point(259, 18);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(59, 20);
            this.btnView.TabIndex = 22;
            this.btnView.Text = "Show";
            this.btnView.UseVisualStyleBackColor = true;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox3.Controls.Add(this.updisplay);
            this.groupBox3.Controls.Add(this.buttonS);
            this.groupBox3.Controls.Add(this.buttonF);
            this.groupBox3.Controls.Add(this.downdisplay);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.DarkGray;
            this.groupBox3.Location = new System.Drawing.Point(9, 6);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox3.Size = new System.Drawing.Size(308, 458);
            this.groupBox3.TabIndex = 30;
            this.groupBox3.TabStop = false;
            // 
            // updisplay
            // 
            this.updisplay.BackColor = System.Drawing.SystemColors.Highlight;
            this.updisplay.Image = global::Lift.Properties.Resources._1;
            this.updisplay.Location = new System.Drawing.Point(241, 61);
            this.updisplay.Name = "updisplay";
            this.updisplay.Size = new System.Drawing.Size(51, 43);
            this.updisplay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.updisplay.TabIndex = 23;
            this.updisplay.TabStop = false;
            // 
            // buttonS
            // 
            this.buttonS.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonS.Location = new System.Drawing.Point(241, 110);
            this.buttonS.Name = "buttonS";
            this.buttonS.Size = new System.Drawing.Size(51, 48);
            this.buttonS.TabIndex = 10;
            this.buttonS.Text = "R";
            this.buttonS.UseVisualStyleBackColor = false;
            this.buttonS.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // buttonF
            // 
            this.buttonF.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonF.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonF.Location = new System.Drawing.Point(241, 350);
            this.buttonF.Name = "buttonF";
            this.buttonF.Size = new System.Drawing.Size(57, 48);
            this.buttonF.TabIndex = 11;
            this.buttonF.Text = "R";
            this.buttonF.UseVisualStyleBackColor = false;
            this.buttonF.Click += new System.EventHandler(this.buttong_Click_1);
            // 
            // downdisplay
            // 
            this.downdisplay.BackColor = System.Drawing.SystemColors.Highlight;
            this.downdisplay.Image = global::Lift.Properties.Resources._1;
            this.downdisplay.Location = new System.Drawing.Point(241, 301);
            this.downdisplay.Name = "downdisplay";
            this.downdisplay.Size = new System.Drawing.Size(57, 43);
            this.downdisplay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.downdisplay.TabIndex = 24;
            this.downdisplay.TabStop = false;
            this.downdisplay.Click += new System.EventHandler(this.downdisplay_Click);
            // 
            // buttonclose
            // 
            this.buttonclose.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonclose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonclose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonclose.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonclose.Location = new System.Drawing.Point(501, 364);
            this.buttonclose.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonclose.Name = "buttonclose";
            this.buttonclose.Size = new System.Drawing.Size(66, 46);
            this.buttonclose.TabIndex = 27;
            this.buttonclose.Text = "Close";
            this.buttonclose.UseVisualStyleBackColor = false;
            this.buttonclose.Click += new System.EventHandler(this.buttonclose_Click);
            // 
            // Sbutton
            // 
            this.Sbutton.BackColor = System.Drawing.SystemColors.Highlight;
            this.Sbutton.BackgroundImage = global::Lift.Properties.Resources._1;
            this.Sbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Sbutton.Location = new System.Drawing.Point(501, 415);
            this.Sbutton.Name = "Sbutton";
            this.Sbutton.Size = new System.Drawing.Size(66, 49);
            this.Sbutton.TabIndex = 17;
            this.Sbutton.UseVisualStyleBackColor = false;
            this.Sbutton.Click += new System.EventHandler(this.buttoni1_Click_1);
            // 
            // buttonopen
            // 
            this.buttonopen.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonopen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonopen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonopen.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonopen.Location = new System.Drawing.Point(427, 364);
            this.buttonopen.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonopen.Name = "buttonopen";
            this.buttonopen.Size = new System.Drawing.Size(61, 46);
            this.buttonopen.TabIndex = 26;
            this.buttonopen.Text = "Open";
            this.buttonopen.UseVisualStyleBackColor = false;
            this.buttonopen.Click += new System.EventHandler(this.buttonopen_Click);
            // 
            // Fbutton
            // 
            this.Fbutton.BackColor = System.Drawing.SystemColors.Highlight;
            this.Fbutton.BackgroundImage = global::Lift.Properties.Resources._0;
            this.Fbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Fbutton.Location = new System.Drawing.Point(427, 415);
            this.Fbutton.Name = "Fbutton";
            this.Fbutton.Size = new System.Drawing.Size(61, 49);
            this.Fbutton.TabIndex = 18;
            this.Fbutton.UseVisualStyleBackColor = false;
            this.Fbutton.Click += new System.EventHandler(this.buttonig_Click_1);
            // 
            // rightup
            // 
            this.rightup.BackgroundImage = global::Lift.Properties.Resources.right;
            this.rightup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.rightup.Location = new System.Drawing.Point(160, 54);
            this.rightup.Name = "rightup";
            this.rightup.Size = new System.Drawing.Size(84, 182);
            this.rightup.TabIndex = 13;
            this.rightup.TabStop = false;
            // 
            // Indisplay
            // 
            this.Indisplay.BackColor = System.Drawing.SystemColors.Highlight;
            this.Indisplay.Image = global::Lift.Properties.Resources._1;
            this.Indisplay.Location = new System.Drawing.Point(326, 364);
            this.Indisplay.Name = "Indisplay";
            this.Indisplay.Size = new System.Drawing.Size(92, 100);
            this.Indisplay.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Indisplay.TabIndex = 25;
            this.Indisplay.TabStop = false;
            this.Indisplay.Click += new System.EventHandler(this.Indisplay_Click);
            // 
            // leftup
            // 
            this.leftup.BackgroundImage = global::Lift.Properties.Resources.left;
            this.leftup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.leftup.Location = new System.Drawing.Point(76, 54);
            this.leftup.Name = "leftup";
            this.leftup.Size = new System.Drawing.Size(84, 182);
            this.leftup.TabIndex = 12;
            this.leftup.TabStop = false;
            // 
            // leftdown
            // 
            this.leftdown.BackgroundImage = global::Lift.Properties.Resources.left;
            this.leftdown.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.leftdown.Location = new System.Drawing.Point(76, 283);
            this.leftdown.Name = "leftdown";
            this.leftdown.Size = new System.Drawing.Size(84, 182);
            this.leftdown.TabIndex = 14;
            this.leftdown.TabStop = false;
            // 
            // rightdown
            // 
            this.rightdown.BackgroundImage = global::Lift.Properties.Resources.right;
            this.rightdown.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.rightdown.Location = new System.Drawing.Point(160, 283);
            this.rightdown.Name = "rightdown";
            this.rightdown.Size = new System.Drawing.Size(84, 182);
            this.rightdown.TabIndex = 15;
            this.rightdown.TabStop = false;
            // 
            // inside
            // 
            this.inside.BackgroundImage = global::Lift.Properties.Resources.open;
            this.inside.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.inside.Location = new System.Drawing.Point(77, 54);
            this.inside.Name = "inside";
            this.inside.Size = new System.Drawing.Size(166, 182);
            this.inside.TabIndex = 7;
            this.inside.TabStop = false;
            // 
            // Elevator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 473);
            this.Controls.Add(this.buttonclose);
            this.Controls.Add(this.Sbutton);
            this.Controls.Add(this.buttonopen);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Data);
            this.Controls.Add(this.Fbutton);
            this.Controls.Add(this.rightup);
            this.Controls.Add(this.Indisplay);
            this.Controls.Add(this.leftup);
            this.Controls.Add(this.leftdown);
            this.Controls.Add(this.rightdown);
            this.Controls.Add(this.inside);
            this.Controls.Add(this.groupBox3);
            this.MaximizeBox = false;
            this.Name = "Elevator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Elevator System";
            this.Load += new System.EventHandler(this.Elevator_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.updisplay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.downdisplay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Indisplay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leftdown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rightdown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inside)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox inside;
        private System.Windows.Forms.PictureBox leftup;
        private System.Windows.Forms.PictureBox rightup;
        private System.Windows.Forms.PictureBox leftdown;
        private System.Windows.Forms.PictureBox rightdown;
        private System.Windows.Forms.Button Sbutton;
        private System.Windows.Forms.Button Fbutton;
        private System.Windows.Forms.ListBox Data;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.Timer moveuptimer;
        private System.Windows.Forms.Timer movedowntimer;
        private System.Windows.Forms.Timer upOpenTimer;
        private System.Windows.Forms.Timer downOpenTimer;
        private System.Windows.Forms.Timer downclosetimer;
        private System.Windows.Forms.Timer upclosetimer;
        private System.Windows.Forms.Timer timeauto;
        private System.Windows.Forms.Timer timerautoup;
        private System.Windows.Forms.Timer timerautodown;
        private System.Windows.Forms.PictureBox Indisplay;
        private System.Windows.Forms.Button buttonopen;
        private System.Windows.Forms.Button buttonclose;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonF;
        private System.Windows.Forms.PictureBox downdisplay;
        private System.Windows.Forms.Button buttonS;
        private System.Windows.Forms.PictureBox updisplay;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}

